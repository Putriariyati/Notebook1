<?php

return [
    'Thank you', 'For your registration', 'Add new list', 'And delete this one', 'Enjoy using app'
];